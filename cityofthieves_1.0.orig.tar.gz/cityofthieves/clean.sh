rm *.o

rm -rf release
rm -rf debug
